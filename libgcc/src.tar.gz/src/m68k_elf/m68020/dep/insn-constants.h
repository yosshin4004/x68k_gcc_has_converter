/* Generated automatically by the program `genconstants'
   from the machine description file `md'.  */

#ifndef GCC_INSN_CONSTANTS_H
#define GCC_INSN_CONSTANTS_H

#define UNSPEC_TIE 5
#define UNSPECV_CAS_2 2
#define PIC_REG 13
#define D0_REG 0
#define UNSPECV_TAS_1 3
#define SP_REG 15
#define A6_REG 14
#define UNSPECV_CAS_1 1
#define UNSPEC_RELOC16 6
#define FP0_REG 16
#define UNSPEC_SIN 1
#define UNSPEC_RELOC32 7
#define UNSPEC_COS 2
#define UNSPECV_BLOCKAGE 0
#define UNSPECV_TAS_2 4
#define UNSPEC_IB 4
#define A0_REG 8
#define A1_REG 9
#define UNSPEC_GOT 3

#endif /* GCC_INSN_CONSTANTS_H */
